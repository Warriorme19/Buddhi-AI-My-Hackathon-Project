/**
 * Intelligence Engine Service
 * Implements Probability Engine, Trend Detection, Gap Analysis, etc.
 */

interface Topic {
  id: string;
  name: string;
  short: string;
  system: string;
  probability: number;
  trend: number; // -2 to 2
  questions: string[];
  lastPractice?: Date;
  mastery: number; // 0 to 1
}

const MOCK_TOPICS: Topic[] = [
  { id: '1', name: "Myocardial Infarction", short: "MI", system: "Cardiology", probability: 94, trend: 2, questions: ["RCA territory occlusion in inferior MI", "Cardiac biomarkers timeline post-MI"], mastery: 0.4 },
  { id: '2', name: "Heart Failure", short: "HF", system: "Cardiology", probability: 85, trend: 1, questions: ["Systolic vs diastolic dysfunction", "BNP in heart failure diagnosis"], mastery: 0.6 },
  { id: '3', name: "Biochem Pathways", short: "Glyco", system: "Biochemistry", probability: 88, trend: 2, questions: ["Rate-limiting steps in glycolysis", "TCA cycle enzyme deficiencies"], mastery: 0.3 },
  { id: '4', name: "Hypersensitivity", short: "Hyp", system: "Immunology", probability: 78, trend: 0, questions: ["Type I vs Type III reaction", "Serum sickness mechanism"], mastery: 0.8 },
  { id: '5', name: "Acid-Base平衡", short: "A/B", system: "Renal", probability: 84, trend: 2, questions: ["Metabolic acidosis algorithm", "Respiratory compensation"], mastery: 0.5 },
  { id: '6', name: "Antibiotics", short: "Abx", system: "Pharmacology", probability: 74, trend: 1, questions: ["Mechanism of fluoroquinolones", "MRSA treatment options"], mastery: 0.7 },
  { id: '7', name: "Brain Anatomy", short: "CNS", system: "Neuro", probability: 62, trend: 0, questions: ["Basal ganglia circuitry", "Internal capsule anatomy"], mastery: 0.45 },
  { id: '8', name: "Neoplasia", short: "Neo", system: "Pathology", probability: 77, trend: 1, questions: ["Proto-oncogene vs tumor suppressor", "Warburg effect mechanism"], mastery: 0.55 },
];

export function analyzeDocument(data: any) {
  return {
    status: 'success',
    concepts: MOCK_TOPICS.map(t => t.name),
    clusters: 8,
    message: "Extraction complete. 124 concepts identified."
  };
}

export function getProbability() {
  return MOCK_TOPICS.map(t => ({
    ...t,
    confidence: 0.85 + Math.random() * 0.1
  }));
}

export function getTrends() {
  return MOCK_TOPICS.filter(t => t.trend > 0).map(t => ({
    name: t.name,
    change: t.trend
  }));
}

export function getGapAnalysis() {
  return MOCK_TOPICS.filter(t => t.probability > 75 && t.mastery < 0.5).map(t => ({
    topic: t.name,
    importance: t.probability,
    practice: t.mastery,
    status: "High importance, low practice"
  }));
}

export function trackPractice(data: { topicId: string, correct: boolean, time: number }) {
  // Stress Detection Logic
  const recentFailures = 2; // In real app, this would be from a DB/Session
  const isStressed = !data.correct && recentFailures >= 2;

  return {
    success: true,
    feedback: data.correct ? "Excellent. Concept reinforced." : "Topic highlighted for revision.",
    trigger: isStressed ? "FATIGUE_DETECTED" : "NORMAL",
    timeToMastery: data.correct ? "Fast tracking..." : "Recommended revisit in 48h"
  };
}

export function getStudyPlan() {
  return {
    daysLeft: 14,
    schedule: [
      { day: 1, focus: "Cardiology", tasks: ["MI Management", "HF Drugs"] },
      { day: 2, focus: "Biochemistry", tasks: ["Glycolysis", "Enzyme kinetics"] },
      { day: 3, focus: "Renal", tasks: ["Acid-Base Disorders", "Electrolytes"] }
    ]
  };
}

export function getEvidence(topicId: string) {
  const topic = MOCK_TOPICS.find(t => t.id === topicId) || MOCK_TOPICS[0];
  return {
    topic: topic.name,
    evidence: [
      { year: 2023, marks: 4, type: "Clinical Case" },
      { year: 2022, marks: 2, type: "Recall" },
      { year: 2021, marks: 5, type: "High Yield" }
    ],
    explanation: `Topic has appeared ${topic.probability > 80 ? 'frequently' : 'moderately'} in recent boards with high marks weightage.`
  };
}

export function getChatResponse(message: string) {
  return {
    message: `Based on your recent performance in ${MOCK_TOPICS[0].system}, I suggest focusing on ${MOCK_TOPICS[0].name}. It has a ${MOCK_TOPICS[0].probability}% appearance probability. Would you like to start a practice session?`,
    suggestions: ["Start Practice", "Show Heatmap", "Explain why?"]
  };
}
