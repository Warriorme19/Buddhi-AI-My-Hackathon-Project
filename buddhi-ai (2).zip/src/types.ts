export interface Topic {
  id: string;
  name: string;
  short: string;
  system: string;
  probability: number;
  trend: number;
  questions: string[];
  mastery: number;
  confidence?: number;
}

export type UIState = 'NORMAL' | 'HIGH_YIELD' | 'FOCUS' | 'FATIGUE_DETECTED';

export interface StudyTask {
  id: string;
  topic: string;
  status: 'pending' | 'completed';
  day: number;
}
