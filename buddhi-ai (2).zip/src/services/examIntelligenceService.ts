import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface IntelligenceData {
  concepts: {
    name: string;
    topic: string;
    frequency: number;
    weight_score: number;
    probability: number;
    trend: 'increasing' | 'decreasing' | 'stable';
    evidence: { year: number; marks: number; question: string }[];
  }[];
  high_priority_topics: string[];
  gaps: string[];
  study_plan: { day: number; focus: string; tasks: string[] }[];
  high_yield_mode: boolean;
}

export async function runExamIntelligence(content: string, daysLeft: number = 14, studentData?: any): Promise<IntelligenceData> {
  const prompt = `
You are an advanced Exam Intelligence Engine for "Buddhi AI".
Analyze the given content (which contains Previous Year Questions (PYQs), metadata, and possibly student data) and generate deep academic insights.

CONTENT:
${content}

${studentData ? `STUDENT DATA: ${JSON.stringify(studentData)}` : ""}
DAYS LEFT: ${daysLeft}

TASKS:
1. Group questions by underlying concepts (not keywords).
2. Assign each group a clear concept name.
3. Map each concept to a syllabus topic.
4. Calculate importance using:
   * Frequency
   * Marks weight
   * Recency (recent years = higher weight)
5. Predict probability (0–100%) of each concept appearing in the next exam.
6. Detect trend: increasing, decreasing, or stable.
7. Provide evidence:
   * Year
   * Marks
   * Short question snippet
8. If student data is provided:
   * Identify weak topics
   * Highlight high-probability gaps
9. Generate a smart study plan:
   * Prioritize high-probability topics
   * Include revision strategy
10. If daysLeft <= 3:
   * Activate High-Yield Mode
   * Return only top concepts

RULES:
* Think conceptually, not keyword-based
* Be precise and structured
* No fluff, no generic answers
* Act like an exam strategist

OUTPUT STRICTLY IN JSON format:
{
  "concepts": [
    {
      "name": "Concept Name",
      "topic": "Syllabus Topic",
      "frequency": number,
      "weight_score": number,
      "probability": number,
      "trend": "increasing | decreasing | stable",
      "evidence": [
        { "year": number, "marks": number, "question": "Short snippet" }
      ]
    }
  ],
  "high_priority_topics": ["Topic A", "Topic B"],
  "gaps": ["Weakness 1"],
  "study_plan": [
    { "day": number, "focus": "Topic", "tasks": ["Task 1"] }
  ],
  "high_yield_mode": boolean
}
`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json"
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Error:", error);
    throw error;
  }
}
