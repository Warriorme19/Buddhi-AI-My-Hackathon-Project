import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer
} from 'recharts';
import { User, Award, Shield, History, MapPin, Zap, Brain, MessageCircle } from 'lucide-react';
import { cn } from '../lib/utils';

const PERFORMANCE_DATA = [
  { day: 'Mon', score: 65 },
  { day: 'Tue', score: 72 },
  { day: 'Wed', score: 85 },
  { day: 'Thu', score: 78 },
  { day: 'Fri', score: 92 },
  { day: 'Sat', score: 88 },
  { day: 'Sun', score: 95 },
];

export default function Profile() {
  return (
    <div className="space-y-8 max-w-6xl mx-auto pb-12 h-screen overflow-y-auto custom-scrollbar pr-4">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Left Col: Info & Metrics */}
        <div className="lg:col-span-4 space-y-6 w-full lg:w-[350px] shrink-0">
          <div className="glass-card p-8 flex flex-col items-center text-center relative overflow-hidden">
             <div className="w-24 h-24 rounded-2xl border-2 border-neon p-0.5 mb-4 relative z-10">
                <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Lucky" className="rounded-2xl" alt="avatar" />
             </div>
             <h2 className="text-2xl font-display font-bold text-white mb-1">XYZ</h2>
             <p className="font-mono text-neon text-[10px] uppercase tracking-widest mb-6">Master Strategist • Level 42</p>
             
             <div className="w-full space-y-4">
                <MetricRow icon={Clock} label="Total Neural Hours" value="24h" color="text-neon" />
                <MetricRow icon={Brain} label="Memory Strength" value="82%" color="text-purple" />
                <MetricRow icon={Zap} label="Avg Prediction Match" value="89%" color="text-neon-red" />
             </div>

             <button className="w-full mt-8 py-3 rounded-xl border border-white/10 hover:border-neon transition-all font-display font-medium text-xs text-white">
                Edit Protocol Settings
             </button>
          </div>

          <div className="glass-card p-8 bg-gradient-to-br from-purple/5 to-transparent">
             <h3 className="font-display font-bold text-[10px] uppercase tracking-[2px] text-slate-500 mb-6 flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                DAILY REFLECTION
             </h3>
             <div className="space-y-6">
                <div>
                   <p className="text-xs text-slate-300 mb-3">How ready do you feel today?</p>
                   <div className="flex flex-wrap gap-2">
                      {['Exhausted', 'Neutral', 'Masterful'].map(mood => (
                        <button key={mood} className="px-3 py-1.5 rounded-lg border border-white/5 bg-white/5 text-[10px] font-mono hover:border-purple transition-all">{mood}</button>
                      ))}
                   </div>
                </div>
                <div>
                   <p className="text-xs text-slate-300 mb-3">Today's primary neural goal?</p>
                   <input 
                      type="text" 
                      placeholder="e.g. Master Renal Pathophys"
                      className="w-full bg-bg/50 border border-white/10 rounded-lg p-3 text-xs placeholder:text-slate-600 outline-none focus:border-neon"
                   />
                </div>
             </div>
          </div>
        </div>

        {/* Right Col: Charts & Activity */}
        <div className="flex-1 space-y-8">
           <div className="glass-card p-8 min-h-[400px] flex flex-col">
              <div className="flex items-center justify-between mb-8">
                <h3 className="font-display font-bold text-[10px] uppercase tracking-[3px] text-slate-500">Neural Efficiency Over Time</h3>
                <div className="flex gap-4">
                   <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500">
                      <div className="w-2 h-2 rounded-full bg-neon" /> mastery level
                   </div>
                </div>
              </div>
              
              <div className="flex-1 w-full">
                 <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={PERFORMANCE_DATA}>
                      <defs>
                        <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="var(--color-neon)" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="var(--color-neon)" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                      <XAxis 
                        dataKey="day" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#4a5568', fontSize: 10, fontFamily: 'JetBrains Mono' }} 
                        dy={10}
                      />
                      <YAxis 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#4a5568', fontSize: 10, fontFamily: 'JetBrains Mono' }} 
                      />
                      <Tooltip 
                        contentStyle={{ backgroundColor: '#0d0f1e', borderColor: 'rgba(79,158,255,0.2)', borderRadius: '12px' }}
                        itemStyle={{ fontSize: '12px', fontFamily: 'Exo 2' }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="score" 
                        stroke="var(--color-neon)" 
                        fillOpacity={1} 
                        fill="url(#colorScore)" 
                        strokeWidth={3}
                      />
                    </AreaChart>
                 </ResponsiveContainer>
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="glass-card p-8">
                 <h3 className="font-display font-bold text-[10px] uppercase tracking-[3px] text-slate-500 mb-6">Recent Insights</h3>
                 <div className="space-y-4 text-xs text-slate-400 font-mono italic leading-relaxed">
                    "Your performance in <span className="text-neon-red">Renal Pathophys</span> peaks between 10am and 12pm. We suggest scheduling deep study during this window."
                 </div>
              </div>
              <div className="glass-card p-8">
                 <h3 className="font-display font-bold text-[10px] uppercase tracking-[3px] text-slate-500 mb-6">Prediction Match</h3>
                 <div className="flex items-center gap-6">
                    <div className="text-4xl font-display font-bold text-white">89%</div>
                    <div className="flex-1 h-3 bg-white/5 rounded-full overflow-hidden">
                       <div className="w-[89%] h-full bg-gradient-to-r from-neon to-purple" />
                    </div>
                 </div>
              </div>
           </div>

           <div className="glass-card p-8 bg-gradient-to-br from-neon/5 to-transparent">
              <h3 className="font-display font-bold text-[10px] uppercase tracking-[3px] text-slate-500 mb-8 flex items-center gap-2">
                 <Award className="w-4 h-4 text-neon" />
                 GLOBAL LEADERBOARD
              </h3>
              <div className="space-y-4">
                 {[
                    { rank: 1, name: 'CyberDoc', score: 12450, delta: '+120', avatar: '1' },
                    { rank: 2, name: 'XYZ', score: 11820, delta: '+450', avatar: 'Lucky', isUser: true },
                    { rank: 3, name: 'NeuralNomad', score: 11200, delta: '-50', avatar: '3' },
                    { rank: 4, name: 'BioHacker', score: 9800, delta: '+300', avatar: '4' },
                    { rank: 5, name: 'MedMind', score: 8500, delta: '+10', avatar: '5' },
                 ].map((player, i) => (
                    <motion.div 
                       key={player.name}
                       initial={{ opacity: 0, x: -10 }}
                       animate={{ opacity: 1, x: 0 }}
                       transition={{ delay: i * 0.1 }}
                       className={cn(
                          "flex items-center justify-between p-4 rounded-xl border transition-all",
                          player.isUser 
                            ? "bg-neon/10 border-neon/30 shadow-[0_0_20px_rgba(79,158,255,0.1)]" 
                            : "bg-white/5 border-white/5 hover:bg-white/10"
                       )}
                    >
                       <div className="flex items-center gap-4">
                          <span className={cn(
                             "font-mono font-bold text-sm w-4",
                             player.rank === 1 ? "text-neon-yellow" : player.rank === 2 ? "text-slate-300" : "text-slate-500"
                          )}>
                             {player.rank}
                          </span>
                          <div className="w-10 h-10 rounded-lg overflow-hidden border border-white/10">
                             <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${player.avatar}`} alt="av" />
                          </div>
                          <div>
                             <p className={cn("text-xs font-display font-bold uppercase tracking-wide", player.isUser ? "text-white" : "text-slate-300")}>
                                {player.name}
                             </p>
                             <p className="text-[9px] font-mono text-slate-500">Elite Strategist</p>
                          </div>
                       </div>
                       <div className="text-right">
                          <p className="text-sm font-display font-bold text-white">{player.score.toLocaleString()} XP</p>
                          <p className={cn(
                             "text-[9px] font-mono",
                             player.delta.startsWith('+') ? "text-neon-green" : "text-neon-red"
                          )}>
                             {player.delta} today
                          </p>
                       </div>
                    </motion.div>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}

function MetricRow({ icon: Icon, label, value, color }: any) {
  return (
    <div className="flex items-center justify-between py-3 border-b border-white/5 last:border-0 grow">
      <div className="flex items-center gap-2">
        <Icon className={cn("w-3.5 h-3.5 text-slate-400")} />
        <span className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">{label}</span>
      </div>
      <span className={cn("font-display font-bold text-lg", color)}>{value}</span>
    </div>
  );
}

function Clock({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <polyline points="12 6 12 12 16 14" />
    </svg>
  );
}
