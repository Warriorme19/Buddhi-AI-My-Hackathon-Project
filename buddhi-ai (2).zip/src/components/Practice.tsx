import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2, XCircle, ChevronRight, Zap, Trophy, Timer } from 'lucide-react';
import { cn } from '../lib/utils';
import { UIState } from '../types';

export default function Practice({ onStateChange }: { onStateChange: (state: UIState) => void }) {
  const [streak, setStreak] = useState(0);
  const [showFeedback, setShowFeedback] = useState<'CORRECT' | 'WRONG' | null>(null);
  const [questionIndex, setQuestionIndex] = useState(0);

  const mockQuestions = [
    {
      topic: "Cardiology",
      subtopic: "Myocardial Infarction",
      question: "Exogenous administration of which agent is most likely to reduce the mortality in a patient presenting 3 hours after the onset of inferior ST-elevation myocardial infarction?",
      options: ["Atenolol", "Lisinopril", "Aspirin", "Nifedipine"],
      correct: 2
    },
    {
      topic: "Renal",
      subtopic: "Acid-Base",
      question: "A patient with persistent vomiting has a pH of 7.50, PCO2 48 mmHg, and HCO3 36 mEq/L. What is the most likely primary acid-base disorder?",
      options: ["Metabolic Acidosis", "Metabolic Alkalosis", "Respiratory Acidosis", "Respiratory Alkalosis"],
      correct: 1
    }
  ];

  const handleAnswer = async (isCorrect: boolean) => {
    if (isCorrect) {
      setStreak(s => s + 1);
      setShowFeedback('CORRECT');
    } else {
      setStreak(0);
      setShowFeedback('WRONG');
      // Potential stress trigger simulation
      if (streak === 0) onStateChange('FATIGUE_DETECTED');
    }

    // Call backend
    await fetch('/api/practice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        topicId: '1',
        correct: isCorrect,
        time: 15
      })
    });

    setTimeout(() => {
      setShowFeedback(null);
      setQuestionIndex((prev) => (prev + 1) % mockQuestions.length);
      if (isCorrect) onStateChange('NORMAL');
    }, 1200);
  };

  return (
    <div className="max-w-4xl mx-auto h-full flex flex-col pt-10">
      {/* Header Info */}
      <div className="flex items-center justify-between mb-10">
        <div>
          <h2 className="font-display font-bold text-2xl uppercase tracking-wider text-glow">Practice Environment</h2>
          <p className="text-xs text-slate-400 font-mono">Simulating high-stakes examination parameters</p>
        </div>
        <div className="flex gap-4">
          <div className="glass px-6 py-3 rounded-2xl border-neon-green/20 flex items-center gap-3">
             <Trophy className="w-5 h-5 text-neon-green" />
             <div>
               <p className="text-[10px] font-mono text-slate-500">STREAK</p>
               <p className="text-xl font-bold text-white">{streak}</p>
             </div>
          </div>
          <div className="glass px-6 py-3 rounded-2xl border-neon/20 flex items-center gap-3">
             <Timer className="w-5 h-5 text-neon" />
             <div>
               <p className="text-[10px] font-mono text-slate-500">AVG TIME</p>
               <p className="text-xl font-bold text-white">12.4s</p>
             </div>
          </div>
        </div>
      </div>

      <AnimatePresence mode="wait">
        {!showFeedback ? (
          <motion.div 
            key="question"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="flex-1"
          >
            <div className="glass-card p-10 space-y-8 relative overflow-hidden">
               {/* Background pattern */}
               <div className="absolute top-0 right-0 w-64 h-64 bg-neon/5 rounded-full blur-3xl -mr-32 -mt-32" />
               
               <div className="flex items-center gap-3">
                 <span className="px-3 py-1 bg-white/10 rounded-full text-[10px] font-bold text-neon-green border border-neon-green/20">
                   {mockQuestions[questionIndex].topic}
                 </span>
                 <ChevronRight className="w-4 h-4 text-slate-600" />
                 <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                   {mockQuestions[questionIndex].subtopic}
                 </span>
               </div>

               <h3 className="text-2xl font-medium leading-relaxed text-slate-200">
                 {mockQuestions[questionIndex].question}
               </h3>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-12">
                 {mockQuestions[questionIndex].options.map((option, idx) => (
                   <button
                    key={idx}
                    onClick={() => handleAnswer(idx === mockQuestions[questionIndex].correct)}
                    className="p-6 rounded-2xl glass-card text-left border-white/5 hover:border-neon hover:bg-neon/5 transition-all group relative overflow-hidden"
                   >
                     <div className="absolute left-0 top-0 bottom-0 w-1 bg-neon/0 group-hover:bg-neon transition-all" />
                     <span className="text-xs font-mono text-slate-500 mr-4">0{idx + 1}</span>
                     <span className="font-medium">{option}</span>
                   </button>
                 ))}
               </div>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            key="feedback"
            className="flex-1 flex flex-col items-center justify-center space-y-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            {showFeedback === 'CORRECT' ? (
              <motion.div 
                className="flex flex-col items-center"
                initial={{ scale: 0 }} 
                animate={{ scale: 1 }}
              >
                <div className="w-24 h-24 bg-neon-green/20 rounded-full flex items-center justify-center border-4 border-neon-green shadow-[0_0_50px_rgba(34,197,94,0.4)]">
                   <CheckCircle2 className="w-12 h-12 text-neon-green" />
                </div>
                <h4 className="text-4xl font-display font-bold mt-8 text-neon-green uppercase tracking-widest text-glow italic">Target Neutralized</h4>
                <p className="text-slate-400 font-mono mt-2">Pathway reinforced with +0.4 Mastery</p>
                
                {/* Particle burst simulation */}
                <div className="flex gap-2 mt-6">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <motion.div 
                      key={i}
                      animate={{ y: [-20, -100], opacity: [1, 0], scale: [1, 0.5] }}
                      transition={{ duration: 1, repeat: Infinity, delay: i * 0.1 }}
                      className="w-2 h-2 bg-neon-green rounded-full"
                    />
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div 
                className="flex flex-col items-center"
                animate={{ x: [-10, 10, -10, 10, 0] }}
              >
                <div className="w-24 h-24 bg-neon-red/20 rounded-full flex items-center justify-center border-4 border-neon-red shadow-[0_0_50px_rgba(255,61,107,0.4)]">
                   <XCircle className="w-12 h-12 text-neon-red" />
                </div>
                <h4 className="text-4xl font-display font-bold mt-8 text-neon-red uppercase tracking-widest text-glow italic">System Anomaly</h4>
                <p className="text-slate-400 font-mono mt-2">Recommended: Review Cardiology Pathophysiology</p>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
