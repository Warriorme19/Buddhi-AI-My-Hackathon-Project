import { motion } from 'motion/react';
import { Topic } from '../types';
import { cn } from '../lib/utils';

interface HeatmapProps {
  topics: Topic[];
  onSelectTopic: (topic: Topic) => void;
}

export default function Heatmap({ topics, onSelectTopic }: HeatmapProps) {
  const getProbColor = (prob: number) => {
    if (prob >= 70) return '#ff3d6b';
    if (prob >= 40) return '#f0c040';
    return '#22c55e';
  };

  const getCellClass = (prob: number) => {
    if (prob >= 70) return 'hm-cell-hi';
    if (prob >= 40) return 'hm-cell-mid';
    return 'hm-cell-lo';
  };

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-5 gap-3">
      {topics.map((topic, idx) => {
        const color = getProbColor(topic.probability);
        
        return (
          <motion.div
            key={topic.id}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.02 }}
            onClick={() => onSelectTopic(topic)}
            className={cn("hm-cell group p-3 h-28 flex flex-col justify-between", getCellClass(topic.probability))}
          >
            <div className="text-[10px] font-display font-bold text-white/50 uppercase tracking-widest leading-none">
              {topic.short}
            </div>

            <div className={cn(
              "text-3xl font-display font-bold tracking-tight text-white leading-none text-center py-2",
              topic.probability >= 70 ? "text-neon-red" : topic.probability >= 40 ? "text-neon-yellow" : "text-neon-green"
            )}>
              {topic.probability}%
            </div>

            <div className="h-1.5 bg-white/5 rounded-full overflow-hidden w-full">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${topic.probability}%` }}
                className="h-full rounded-full"
                style={{ backgroundColor: color, boxShadow: `0 0 10px ${color}40` }}
              />
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
