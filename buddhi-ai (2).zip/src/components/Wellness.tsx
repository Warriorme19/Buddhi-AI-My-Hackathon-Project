import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Play, Pause, RotateCcw, Music } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Wellness() {
  const [timeLeft, setTimeLeft] = useState(25 * 60);
  const [isActive, setIsActive] = useState(false);
  const [mode, setMode] = useState<'focus' | 'short' | 'long'>('focus');

  useEffect(() => {
    let interval: any = null;
    if (isActive && timeLeft > 0) {
      interval = setInterval(() => setTimeLeft(t => t - 1), 1000);
    } else if (timeLeft === 0) {
      setIsActive(false);
    }
    return () => clearInterval(interval);
  }, [isActive, timeLeft]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const totalTime = mode === 'focus' ? 25 * 60 : mode === 'short' ? 5 * 60 : 15 * 60;
  const progress = 1 - (timeLeft / totalTime);

  const setTimerMode = (newMode: 'focus' | 'short' | 'long') => {
    setMode(newMode);
    setIsActive(false);
    setTimeLeft(newMode === 'focus' ? 25 * 60 : newMode === 'short' ? 5 * 60 : 15 * 60);
  };

  return (
    <div className="space-y-8 h-full flex flex-col">
      <div>
        <h1 className="text-4xl font-display font-medium text-white mb-2">Wellness</h1>
        <p className="text-[10px] font-mono text-slate-500 uppercase tracking-[4px]">DEEP WORK • REST • MOVE • BREATHE</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 flex-1">
        {/* Pomodoro Timer Section */}
        <div className="lg:col-span-7 glass-card p-10 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="flex items-center gap-2 absolute top-8 left-8">
            <div className="w-1.5 h-1.5 bg-neon rounded-full" />
            <span className="text-[10px] font-display font-bold tracking-widest text-slate-400">POMODORO TIMER</span>
          </div>

          <div className="relative w-80 h-80 flex items-center justify-center mb-12">
            <svg className="absolute inset-0 w-full h-full -rotate-90">
              <circle cx="160" cy="160" r="150" fill="none" stroke="rgba(255,255,255,0.03)" strokeWidth="2" />
              <motion.circle 
                cx="160" cy="160" r="150" fill="none" stroke="var(--color-purple)" strokeWidth="4" 
                strokeDasharray="942" strokeDashoffset={942 * (1 - progress)}
                className="drop-shadow-[0_0_10px_rgba(168,85,247,0.4)]"
              />
            </svg>
            <div className="text-center">
              <h3 className="text-7xl font-display font-medium text-white tracking-wide">{formatTime(timeLeft)}</h3>
              <p className="text-xs font-mono text-slate-500 uppercase tracking-widest mt-2">{mode === 'focus' ? 'FOCUS' : 'REST'}</p>
            </div>
          </div>

          <div className="flex flex-col items-center gap-8 w-full max-w-sm">
            <div className="flex gap-2 p-1 bg-white/5 rounded-full">
              <button 
                onClick={() => setTimerMode('focus')}
                className={cn("px-6 py-2 rounded-full text-[10px] font-display font-bold tracking-widest transition-all", mode === 'focus' ? "bg-purple/20 text-purple border border-purple/30" : "text-slate-500 hover:text-slate-300")}
              >
                FOCUS
              </button>
              <button 
                onClick={() => setTimerMode('short')}
                className={cn("px-6 py-2 rounded-full text-[10px] font-display font-bold tracking-widest transition-all", mode === 'short' ? "bg-purple/20 text-purple border border-purple/30" : "text-slate-500 hover:text-slate-300")}
              >
                SHORT BREAK
              </button>
              <button 
                onClick={() => setTimerMode('long')}
                className={cn("px-6 py-2 rounded-full text-[10px] font-display font-bold tracking-widest transition-all", mode === 'long' ? "bg-purple/20 text-purple border border-purple/30" : "text-slate-500 hover:text-slate-300")}
              >
                LONG BREAK
              </button>
            </div>

            <div className="flex items-center gap-6">
              <button 
                onClick={() => setIsActive(!isActive)}
                className="px-10 py-3 bg-gradient-to-r from-neon to-purple text-white rounded-xl shadow-[0_0_20px_rgba(79,158,255,0.3)] hover:scale-105 transition-all flex items-center gap-3 font-display font-bold tracking-widest"
              >
                {isActive ? <Pause className="w-5 h-5 fill-white" /> : <Play className="w-5 h-5 fill-white" />}
                {isActive ? 'Pause' : 'Start'}
              </button>
              <button onClick={() => setTimeLeft(totalTime)} className="flex flex-col items-center gap-1 group">
                <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center group-hover:border-white/30 transition-all">
                  <RotateCcw className="w-4 h-4 text-slate-500" />
                </div>
                <span className="text-[8px] font-mono text-slate-600 group-hover:text-slate-400">RESET</span>
              </button>
              <button className="flex flex-col items-center gap-1 group">
                <div className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center group-hover:border-white/30 transition-all">
                  <Music className="w-4 h-4 text-slate-500" />
                </div>
                <span className="text-[8px] font-mono text-slate-600 group-hover:text-slate-400">MUSIC</span>
              </button>
            </div>
          </div>
        </div>

        {/* Exercises Section */}
        <div className="lg:col-span-5 space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-1.5 h-1.5 bg-neon rounded-full" />
            <span className="text-[10px] font-display font-bold tracking-widest text-slate-400">STRETCH & RESET</span>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <ExerciseCard icon="🧘" label="Neck Rolls" time="2 MIN" desc="Release tension after long study sessions." />
            <ExerciseCard icon="👁️" label="Eye 20-20-20" time="1 MIN" desc="Every 20 min, look 20 ft away for 20 sec." />
            <ExerciseCard icon="🌬️" label="Box Breathing" time="4 MIN" desc="4-4-4-4 breath to reset focus." />
            <ExerciseCard icon="🤸" label="Seated Twist" time="3 MIN" desc="Gentle spine rotation, both sides." />
            <ExerciseCard icon="✍️" label="Wrist Stretch" time="2 MIN" desc="Prevents strain from long writing sessions." />
            <ExerciseCard icon="⚡" label="Power Nap" time="20 MIN" desc="Short nap to consolidate memory." />
          </div>
        </div>
      </div>
    </div>
  );
}

function ExerciseCard({ icon, label, time, desc }: any) {
  return (
    <div className="glass-card p-5 group cursor-pointer hover:border-neon/30 transition-all h-full flex flex-col">
      <div className="flex justify-between items-start mb-3">
        <div className="text-2xl opacity-60 group-hover:opacity-100 transition-opacity">{icon}</div>
      </div>
      <h4 className="font-display font-bold text-sm text-white mb-1">{label}</h4>
      <p className="text-[9px] font-mono text-neon font-bold uppercase mb-2">{time}</p>
      <p className="text-[10px] text-slate-500 leading-relaxed grow">{desc}</p>
    </div>
  );
}
