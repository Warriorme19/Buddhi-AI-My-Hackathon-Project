import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import Heatmap from './Heatmap';
import NebulaGraph from './NebulaGraph';
import { Topic, UIState } from '../types';
import { Brain, Zap, Activity, Target, TrendingUp, Info } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Dashboard({ uiState }: { uiState: UIState }) {
  const [topics, setTopics] = useState<Topic[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'heatmap' | 'nebula'>('heatmap');
  const [selectedTopic, setSelectedTopic] = useState<Topic | null>(null);
  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('prob');

  useEffect(() => {
    fetch('/api/probability')
      .then(res => res.json())
      .then(data => {
        setTopics(data);
        setLoading(false);
      });
  }, []);

  const filteredTopics = topics
    .filter(t => {
      if (filter === 'all') return true;
      if (filter === 'hi') return t.probability >= 70;
      if (filter === 'mid') return t.probability >= 40 && t.probability < 70;
      if (filter === 'lo') return t.probability < 40;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'prob') return b.probability - a.probability;
      if (sortBy === 'alpha') return a.name.localeCompare(b.name);
      return b.trend - a.trend;
    });

  const highYieldTopics = topics.filter(t => t.probability >= 70).slice(0, 5);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-neon" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-display font-medium">
          Hello <span className="text-neon">XYZ</span> — ready to outsmart the exam?
        </h1>
        <p className="text-[10px] font-mono text-slate-500 uppercase tracking-[3px] mt-2">
          PREDICTION ENGINE • {topics.length} topics • {topics.filter(t => t.probability >= 70).length} high-yield • avg 73%
        </p>
      </div>

      {/* High Yield Alert Banner */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden p-6 rounded-2xl border border-neon-red/30 bg-gradient-to-r from-neon-red/10 to-transparent flex items-center justify-between"
      >
        <div className="flex items-center gap-6 z-10">
          <div className="w-12 h-12 rounded-xl bg-neon-red/20 flex items-center justify-center text-neon-red shadow-[0_0_20px_rgba(255,61,107,0.3)]">
            <Zap className="fill-current" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-white">High-Yield Alert • 5 topics flagged for today</h3>
            <p className="text-xs text-slate-400 font-mono mt-1">Model confidence: 94% • Prioritise these before anything else</p>
          </div>
        </div>
        <div className="flex gap-2 z-10">
          {highYieldTopics.map(t => (
            <div key={t.id} className="px-3 py-1.5 rounded-full border border-white/5 bg-bg/40 text-[10px] font-mono whitespace-nowrap">
              <span className="text-slate-400">{t.short} • </span>
              <span className="text-neon-red font-bold">{t.probability}%</span>
            </div>
          ))}
        </div>
        {/* Aesthetic Flame Background Effect */}
        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-gradient-to-l from-neon-red/5 to-transparent pointer-events-none" />
      </motion.div>

      {/* Tab Switcher */}
      <div className="flex border-b border-white/5 -mx-8 px-8 bg-bg/20">
        <TabButton active={activeTab === 'heatmap'} onClick={() => setActiveTab('heatmap')} label="Probability Heatmap" />
        <TabButton active={activeTab === 'nebula'} onClick={() => setActiveTab('nebula')} label="Knowledge Nebula" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-9 space-y-6">
          <AnimatePresence mode="wait">
            {activeTab === 'heatmap' ? (
              <motion.div 
                key="heatmap"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-4"
              >
                {/* V2 Filter Bar */}
                <div className="flex items-center justify-between flex-wrap gap-4">
                  <div className="flex gap-2">
                    <FilterChip active={filter === 'all'} onClick={() => setFilter('all')} label="ALL" color="border-neon/40 text-neon bg-neon/10" />
                    <FilterChip active={filter === 'hi'} onClick={() => setFilter('hi')} label="HIGH (>70%)" color="border-neon-red/40 text-neon-red hover:bg-neon-red/10" />
                    <FilterChip active={filter === 'mid'} onClick={() => setFilter('mid')} label="MID (40-70%)" color="border-neon-yellow/40 text-neon-yellow hover:bg-neon-yellow/10" />
                    <FilterChip active={filter === 'lo'} onClick={() => setFilter('lo')} label="LOW (<40%)" color="border-neon-green/40 text-neon-green hover:bg-neon-green/10" />
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-mono text-slate-500 uppercase">Sort by:</span>
                    <select 
                      value={sortBy}
                      onChange={(e) => setSortBy(e.target.value)}
                      className="bg-bg-secondary border border-white/10 text-slate-300 rounded-lg px-3 py-1 text-xs font-mono outline-none focus:border-neon transition-colors"
                    >
                      <option value="prob">Probability</option>
                      <option value="alpha">A-Z</option>
                      <option value="trend">Trend</option>
                    </select>
                  </div>
                </div>

                <div className="glass-card p-6 min-h-[500px]">
                  <Heatmap topics={filteredTopics} onSelectTopic={setSelectedTopic} />
                  
                  {/* Legend */}
                  <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between">
                    <div className="flex gap-6">
                      <LegendItem color="bg-neon-red" label="High probability (>70%)" />
                      <LegendItem color="bg-neon-yellow" label="Medium (40-70%)" />
                      <LegendItem color="bg-neon-green" label="Low (<40%)" />
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono italic">Click any cell for details →</span>
                  </div>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="nebula"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
              >
                <div className="flex gap-2 mb-4">
                   <FilterChip active={true} onClick={() => {}} label="All Topics" color="border-neon/40 text-neon" />
                   <FilterChip active={false} onClick={() => {}} label="High Yield" color="border-white/10 text-slate-400" />
                   <FilterChip active={false} onClick={() => {}} label="By System" color="border-white/10 text-slate-400" />
                   <button className="px-4 py-1.5 rounded-full border border-white/10 text-slate-400 font-mono text-[10px] hover:text-white transition-colors ml-auto">
                     Reset View
                   </button>
                </div>
                <div className="grid grid-cols-12 gap-6 h-[500px]">
                  <div className="col-span-9 glass-card overflow-hidden">
                    <NebulaGraph topics={topics} />
                  </div>
                  <div className="col-span-3 space-y-6">
                    <div className="glass-card p-6 h-1/2 flex flex-col justify-center items-center text-center">
                      <div className="text-2xl mb-4 text-white opacity-60">✦</div>
                      <p className="text-[10px] text-slate-500 font-mono leading-relaxed">
                        Hover a node to explore<br />Click to lock details
                      </p>
                    </div>
                    <div className="glass-card p-6 h-1/2 overflow-y-auto custom-scrollbar">
                      <h5 className="font-display font-bold text-[10px] uppercase tracking-[2px] text-slate-500 mb-6">GRAPH LEGEND</h5>
                      <div className="space-y-4">
                        <LegendNode color="bg-neon-red" label="High probability node" />
                        <LegendNode color="bg-neon-yellow" label="Medium probability" />
                        <LegendNode color="bg-neon-green" label="Low probability" />
                        <div className="pt-2 space-y-2 border-t border-white/5 mt-4">
                           <div className="flex items-center gap-3">
                             <div className="w-6 h-px bg-neon/40" />
                             <span className="text-[10px] text-slate-500 font-mono">Strong link</span>
                           </div>
                           <div className="flex items-center gap-3">
                             <div className="w-6 h-px bg-white/10" />
                             <span className="text-[10px] text-slate-500 font-mono">Weak link</span>
                           </div>
                        </div>
                      </div>
                      <div className="mt-8 text-center text-slate-600">
                         <p className="text-[9px] font-mono uppercase tracking-tighter italic">Scroll to zoom • Drag to pan</p>
                         <p className="text-[9px] font-mono uppercase tracking-tighter mt-1 italic">Click node to lock • Click again to unlock</p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* V2 Sidebar */}
        <div className="lg:col-span-3 space-y-6">
          <div className="glass-card p-6 min-h-[320px] flex flex-col justify-center items-center text-center">
            <AnimatePresence mode="wait">
              {selectedTopic ? (
                <motion.div 
                  key="selected"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="w-full text-left space-y-4"
                >
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-2.5 h-2.5 rounded-full",
                      selectedTopic.probability >= 70 ? "bg-neon-red shadow-[0_0_8px_#ff3d6b80]" : 
                      selectedTopic.probability >= 40 ? "bg-neon-yellow shadow-[0_0_8px_#f0c04080]" : 
                      "bg-neon-green shadow-[0_0_8px_#22c55e80]"
                    )} />
                    <h4 className="font-display font-bold text-lg leading-tight uppercase tracking-wide">{selectedTopic.name}</h4>
                  </div>
                  
                  <div>
                    <span className={cn(
                      "text-5xl font-bold font-display tracking-tight leading-none",
                      selectedTopic.probability >= 70 ? "text-neon-red" : 
                      selectedTopic.probability >= 40 ? "text-neon-yellow" : 
                      "text-neon-green"
                    )}>
                      {selectedTopic.probability}%
                    </span>
                    <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest mt-1">
                      Exam Probability · <span className={selectedTopic.trend > 0 ? "text-neon-green" : "text-neon-red"}>{selectedTopic.trend > 0 ? '↑' : '↓'}</span>
                    </p>
                  </div>

                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <p className="text-[10px] font-mono text-slate-500 uppercase tracking-wider mb-2">High Yield Markers</p>
                    {selectedTopic.questions.map((q, i) => (
                      <div key={i} className={cn(
                        "text-[11px] text-slate-400 bg-white/5 p-3 rounded-lg border-l-2 leading-relaxed transition-all",
                        selectedTopic.probability >= 70 ? "border-neon-red/50" : 
                        selectedTopic.probability >= 40 ? "border-neon-yellow/50" : 
                        "border-neon-green/50"
                      )}>
                        {q}
                      </div>
                    ))}
                  </div>

                  <button 
                    onClick={() => setSelectedTopic(null)}
                    className="w-full py-2 text-[10px] font-mono text-slate-600 hover:text-white transition-colors uppercase tracking-widest mt-4 border border-white/5 rounded"
                  >
                    Reset Analysis
                  </button>
                </motion.div>
              ) : (
                <motion.div 
                  key="empty" 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <div className="flex justify-center">
                    <motion.div
                      animate={{ y: [0, -10, 0] }}
                      transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                    >
                      <Brain className="w-12 h-12 text-neon-red/60" />
                    </motion.div>
                  </div>
                  <p className="text-xs text-slate-500 font-mono leading-relaxed tracking-wide">
                    Click a topic cell<br />to see full detail
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="glass-card p-6">
            <h5 className="font-display font-bold text-[11px] uppercase tracking-[2px] text-slate-500 mb-6 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-neon rounded-full" />
              SESSION STATS
            </h5>
            <div className="space-y-3">
              <StatRow label="Topics reviewed" value="7" col="text-neon" />
              <StatRow label="High-yield flagged" value="13" col="text-neon-red" />
              <StatRow label="Avg probability" value="73%" col="text-neon-yellow" />
              <StatRow label="Mastered" value="12" col="text-neon-green" />
            </div>
          </div>

          <div className="glass-card p-6 bg-gradient-to-br from-neon-red/5 to-transparent">
            <h5 className="font-display font-bold text-[11px] uppercase tracking-[2px] text-slate-500 mb-6 flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-neon-red rounded-full shadow-[0_0_5px_#ff3d6b]" />
              STREAK
            </h5>
            <div className="flex items-end gap-3 mb-2">
              <span className="text-5xl font-display font-bold text-white">12</span>
              <span className="text-sm font-mono text-slate-500 mb-1">days straight</span>
            </div>
            <p className="text-[10px] text-slate-400 font-mono uppercase tracking-widest flex items-center gap-2">
              Keep the fire going 🔥
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterChip({ active, onClick, label, color }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "px-4 py-1.5 rounded-full border text-[10px] font-mono font-bold transition-all",
        active ? "opacity-100" : "opacity-40 hover:opacity-100",
        color
      )}
    >
      {label}
    </button>
  );
}

function LegendItem({ color, label }: any) {
  return (
    <div className="flex items-center gap-2">
      <div className={cn("w-2 h-2 rounded-sm", color)} />
      <span className="text-[10px] font-mono text-slate-400">{label}</span>
    </div>
  );
}

function LegendNode({ color, label }: any) {
  return (
    <div className="flex items-center gap-3">
      <div className={cn("w-2.5 h-2.5 rounded-full", color)} />
      <span className="text-[10px] font-mono text-slate-500">{label}</span>
    </div>
  );
}

function TabButton({ active, onClick, label }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "px-8 py-4 text-[11px] font-display font-bold tracking-[2px] uppercase transition-all relative",
        active ? "text-neon bg-white/[0.02]" : "text-slate-500 hover:text-slate-300"
      )}
    >
      {label}
      {active && (
        <motion.div 
          layoutId="tabGlow"
          className="absolute bottom-0 left-0 right-0 h-0.5 bg-neon shadow-[0_0_15px_#4f9eff]"
        />
      )}
    </button>
  );
}

function StatRow({ label, value, col }: any) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-white/5 last:border-0 grow">
      <span className="text-[11px] text-slate-500 font-mono">{label}</span>
      <span className={cn("text-xs font-bold font-mono", col)}>{value}</span>
    </div>
  );
}


