import { useRef, useEffect } from 'react';
import { Topic } from '../types';

interface Node extends Topic {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  color: string;
  glow: string;
  pulsePhase: number;
}

const SYS_COLORS: Record<string, { fill: string, glow: string }> = {
  Cardiology: { fill: "#ff3d6b", glow: "rgba(255,61,107,0.5)" },
  Biochemistry: { fill: "#a855f7", glow: "rgba(168,85,247,0.5)" },
  Immunology: { fill: "#22d3ee", glow: "rgba(34,211,238,0.5)" },
  Pharmacology: { fill: "#f59e0b", glow: "rgba(245,158,11,0.5)" },
  Neuro: { fill: "#4f9eff", glow: "rgba(79,158,255,0.5)" },
  Pathology: { fill: "#f0c040", glow: "rgba(240,192,64,0.5)" },
  Renal: { fill: "#22c55e", glow: "rgba(34,197,94,0.5)" },
};

export default function NebulaGraph({ topics }: { topics: Topic[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrame: number;
    let animT = 0;
    const parent = canvas.parentElement;
    if (!parent) return;

    const resize = () => {
      canvas.width = parent.clientWidth * window.devicePixelRatio;
      canvas.height = parent.clientHeight * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };
    resize();
    window.addEventListener('resize', resize);

    const W = parent.clientWidth;
    const H = parent.clientHeight;

    // Initialize nodes
    const nodes: Node[] = topics.map((t, i) => {
      const angle = (i / topics.length) * Math.PI * 2;
      const radius = 100 + Math.random() * 80;
      const sc = SYS_COLORS[t.system] || { fill: '#4f9eff', glow: 'rgba(79,158,255,.5)' };
      return {
        ...t,
        x: W / 2 + Math.cos(angle) * radius,
        y: H / 2 + Math.sin(angle) * radius,
        vx: 0, vy: 0,
        r: Math.max(16, (t.probability / 100) * 28),
        color: sc.fill,
        glow: sc.glow,
        pulsePhase: Math.random() * Math.PI * 2
      };
    });

    const draw = () => {
      ctx.clearRect(0, 0, W, H);
      animT += 0.015;

      // Stars
      ctx.fillStyle = 'rgba(255,255,255,0.1)';
      for(let i=0; i<30; i++) {
        const x = (Math.sin(i * 123.4) * 0.5 + 0.5) * W;
        const y = (Math.cos(i * 567.8) * 0.5 + 0.5) * H;
        const s = Math.sin(animT + i) * 0.5 + 0.5;
        ctx.beginPath(); ctx.arc(x, y, s, 0, Math.PI*2); ctx.fill();
      }

      // Physics
      nodes.forEach(n => {
        nodes.forEach(m => {
          if (n === m) return;
          const dx = n.x - m.x, dy = n.y - m.y;
          const d = Math.sqrt(dx * dx + dy * dy) || 1;
          if (d < 150) {
            const f = (150 - d) / 150;
            n.vx += (dx / d) * f * 0.15;
            n.vy += (dy / d) * f * 0.15;
          }
        });
        n.vx += (W / 2 - n.x) * 0.0005;
        n.vy += (H / 2 - n.y) * 0.0005;
        n.vx *= 0.92; n.vy *= 0.92;
        n.x += n.vx; n.y += n.vy;
      });

      // Links 
      ctx.lineWidth = 1;
      nodes.forEach((n, i) => {
        nodes.slice(i + 1).forEach(m => {
          const d = Math.hypot(n.x - m.x, n.y - m.y);
          if (d < 180) {
            const alpha = (180 - d) / 180 * 0.1;
            ctx.strokeStyle = `rgba(79,158,255,${alpha})`;
            ctx.beginPath(); ctx.moveTo(n.x, n.y); ctx.lineTo(m.x, m.y); ctx.stroke();
          }
        });
      });

      // Draw Nodes
      nodes.forEach(n => {
        const pulse = Math.sin(animT + n.pulsePhase) * 0.05 + 1;
        const r = n.r * pulse;
        
        // Glow
        const grad = ctx.createRadialGradient(n.x, n.y, r * 0.2, n.x, n.y, r * 3);
        grad.addColorStop(0, n.glow);
        grad.addColorStop(1, 'transparent');
        ctx.fillStyle = grad;
        ctx.beginPath(); ctx.arc(n.x, n.y, r * 3, 0, Math.PI * 2); ctx.fill();

        // Core
        ctx.fillStyle = n.color;
        ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, Math.PI * 2); ctx.fill();
        
        // Shine
        const coreGrad = ctx.createRadialGradient(n.x - r*0.3, n.y - r*0.3, 0, n.x, n.y, r);
        coreGrad.addColorStop(0, 'rgba(255,255,255,0.4)');
        coreGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = coreGrad;
        ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, Math.PI * 2); ctx.fill();

        // Label
        ctx.fillStyle = 'rgba(255,255,255,0.9)';
        ctx.font = "bold 9px 'JetBrains Mono'";
        ctx.textAlign = 'center';
        ctx.fillText(n.short, n.x, n.y + 3);
        
        ctx.fillStyle = 'rgba(255,255,255,0.4)';
        ctx.font = "500 8px Rajdhani";
        ctx.fillText(`${n.probability}%`, n.x, n.y + 12);
      });

      animationFrame = requestAnimationFrame(draw);
    };

    draw();
    return () => {
      cancelAnimationFrame(animationFrame);
      window.removeEventListener('resize', resize);
    };
  }, [topics]);

  return (
    <div className="w-full h-full relative bg-bg-secondary/40 rounded-2xl overflow-hidden backdrop-blur-md">
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
}
