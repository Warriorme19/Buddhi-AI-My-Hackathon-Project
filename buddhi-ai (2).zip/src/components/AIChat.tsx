import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Send, Brain, MoreHorizontal, Paperclip, 
  TrendingUp, TrendingDown, Minus, CheckCircle2, 
  ArrowUpRight, AlertCircle, Calendar, Target,
  Sparkles
} from 'lucide-react';
import { cn } from '../lib/utils';
import { runExamIntelligence, IntelligenceData } from '../services/examIntelligenceService';

export default function AIChat() {
  const [messages, setMessages] = useState<any[]>([
    { role: 'ai', text: "Hello XYZ! I'm your Buddhi AI Intelligence Engine. Upload Previous Year Questions (PYQs) or notes, and I'll generate a deep analysis of high-probability concepts, trends, and a personalized study plan." }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const suggestions = [
    "Upload PYQs for analysis",
    "Predict 2024 probability",
    "Identify high-yield gaps"
  ];

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping, isUploading]);

  const handleSend = async (textOverride?: string) => {
    const messageText = textOverride || input;
    if (!messageText.trim()) return;

    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: messageText }]);
    setIsTyping(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: messageText })
      });
      const data = await res.json();
      setMessages(prev => [...prev, { role: 'ai', text: data.message }]);
    } catch (e) {
      setMessages(prev => [...prev, { role: 'ai', text: "Neural link interrupted. Please try again." }]);
    } finally {
      setIsTyping(false);
    }
  };

  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const fileList = Array.from(files) as File[];
    setMessages(prev => [...prev, { 
      role: 'user', 
      text: `Uploaded ${fileList.length} file(s): ${fileList.map(f => f.name).join(', ')}` 
    }]);

    try {
      let combinedContent = "";
      for (const file of fileList) {
        const text = await readFileAsText(file);
        combinedContent += `--- FILE: ${file.name} ---\n${text}\n\n`;
      }

      // We call the frontend Gemni service directly
      const data = await runExamIntelligence(combinedContent, 10);
      
      setMessages(prev => [...prev, { 
        role: 'ai', 
        type: 'intelligence',
        data: data,
        text: `Analysis complete. I've detected ${data.concepts.length} key concepts. High-Yield Mode is ${data.high_yield_mode ? 'ACTIVE' : 'OFF'}.`
      }]);
    } catch (e) {
      console.error(e);
      setMessages(prev => [...prev, { role: 'ai', text: "Analysis failed. Please ensure files are text-readable (PDFs containing selectable text or .txt/.md files) and try again." }]);
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-5xl mx-auto h-full flex flex-col pt-4 pb-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-8 px-4 shrink-0">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl border border-neon/30 bg-neon/10 flex items-center justify-center shadow-[0_0_20px_rgba(79,158,255,0.2)]">
            <Brain className="w-6 h-6 text-neon" />
          </div>
          <div>
            <h2 className="font-display font-bold text-xl text-white leading-none">Intelligence Engine</h2>
            <div className="flex items-center gap-1.5 mt-1">
               <div className="w-1.5 h-1.5 bg-neon-green rounded-full animate-pulse shadow-[0_0_5px_#4ade80]" />
               <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest leading-none">BUDDHI CORE • v2.4</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden md:flex flex-col items-end">
            <span className="text-[8px] font-mono text-slate-500 uppercase tracking-widest">Processing Power</span>
            <div className="flex gap-0.5 mt-1">
              {[1,2,3,4,5].map(i => <div key={i} className="w-1 h-3 bg-neon rounded-full" />)}
            </div>
          </div>
          <button className="text-slate-500 hover:text-white transition-colors">
            <MoreHorizontal className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Chat History */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-4 space-y-8 custom-scrollbar pb-10"
      >
        {messages.map((msg, idx) => (
          <div key={idx} className={cn("flex", msg.role === 'ai' ? "justify-start" : "justify-end")}>
            <AnimatePresence>
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 10 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                className={cn(
                  "max-w-[90%] md:max-w-[80%] rounded-2xl relative",
                  msg.role === 'user' 
                    ? "bg-neon/10 border border-neon/30 text-white rounded-tr-none px-6 py-4" 
                    : msg.type === 'intelligence'
                      ? "w-full" // Dashboard takes full width
                      : "bg-bg-secondary border border-white/5 text-slate-200 rounded-tl-none px-6 py-4 shadow-[0_4px_20px_rgba(0,0,0,0.2)]"
                )}
              >
                {msg.type === 'intelligence' ? (
                  <IntelligenceDashboard data={msg.data} />
                ) : (
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                )}
              </motion.div>
            </AnimatePresence>
          </div>
        ))}
        {(isTyping || isUploading) && (
          <div className="flex justify-start">
             <div className="bg-bg-secondary border border-white/5 p-5 rounded-2xl rounded-tl-none shadow-xl">
                <div className="flex items-center gap-3">
                   <div className="flex gap-1">
                      <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0 }} className="w-2 h-2 bg-neon rounded-full" />
                      <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.2 }} className="w-2 h-2 bg-neon rounded-full" />
                      <motion.div animate={{ opacity: [0.3, 1, 0.3] }} transition={{ repeat: Infinity, duration: 1, delay: 0.4 }} className="w-2 h-2 bg-neon rounded-full" />
                   </div>
                   <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">
                     {isUploading ? "Extracting intelligence from files..." : "Synthesizing response..."}
                   </span>
                </div>
             </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="p-6 space-y-4 shrink-0 bg-bg/50 backdrop-blur-xl border-t border-white/5 mx-4 rounded-3xl mb-4">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
          {suggestions.map((s, i) => (
            <button 
              key={i} 
              onClick={() => handleSend(s)}
              className="px-4 py-2 rounded-xl border border-white/10 bg-white/5 text-[10px] font-mono text-slate-400 whitespace-nowrap hover:border-purple/50 hover:bg-purple/5 hover:text-white transition-all"
            >
              {s}
            </button>
          ))}
        </div>

        <div className="relative flex items-center gap-3">
          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleFileUpload}
            multiple
            className="hidden"
          />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="w-12 h-12 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-slate-400 hover:text-neon hover:border-neon/50 transition-all shrink-0 active:scale-95"
          >
            <Paperclip className="w-5 h-5" />
          </button>
          
          <div className="relative flex-1 group">
            <input 
              type="text" 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Ask for exam strategy or analysis..."
              className="w-full bg-bg-secondary/50 border border-white/10 rounded-2xl px-6 py-4 pr-16 text-sm text-white placeholder:text-slate-600 outline-none focus:border-neon transition-all shadow-inner"
            />
            <button 
              onClick={() => handleSend()}
              className={cn(
                "absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-xl flex items-center justify-center transition-all",
                input.trim() ? "bg-neon text-bg shadow-[0_0_15px_#4f9eff]" : "bg-white/5 text-slate-600 cursor-not-allowed"
              )}
              disabled={!input.trim()}
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
        <div className="flex justify-between items-center px-2">
          <p className="text-[9px] font-mono text-slate-600 uppercase tracking-widest">
             Neural Engine: Gemini Flash 2.0 • Real-time Sync
          </p>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-neon-green shadow-[0_0_5px_#4ade80]" />
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Encryption Active</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function IntelligenceDashboard({ data }: { data: IntelligenceData }) {
  return (
    <div className="space-y-6 w-full">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-neon-red/10 border border-neon-red/20 flex items-center justify-center shadow-[0_0_20px_rgba(255,61,107,0.15)]">
            <Target className="w-5 h-5 text-neon-red" />
          </div>
          <div>
            <h3 className="font-display font-bold text-lg text-white">EXAM INTELLIGENCE REPORT</h3>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-[3px]">SITUATIONAL AWARENESS • {new Date().toLocaleDateString()}</p>
          </div>
        </div>
        {data.high_yield_mode && (
          <div className="px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-[10px] font-mono text-amber-500 flex items-center gap-2 animate-pulse">
            <AlertCircle className="w-3 h-3" />
            HIGH-YIELD MODE
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Concepts Column */}
        <div className="lg:col-span-8 overflow-x-auto">
          <div className="glass-card p-6 border-white/10 bg-white/[0.02]">
            <h4 className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-[2px] mb-6 flex items-center gap-2">
              <Sparkles className="w-3 h-3" />
              IDENTIFIED CONCEPTS & PROBABILITY
            </h4>
            <div className="space-y-4">
              {data.concepts.map((c, i) => (
                <div key={i} className="group p-4 rounded-xl border border-white/5 bg-white/[0.01] hover:bg-white/[0.04] transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h5 className="font-display font-bold text-white group-hover:text-neon transition-colors uppercase tracking-tight">{c.name}</h5>
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{c.topic}</span>
                    </div>
                    <div className="text-right">
                      <div className={cn(
                        "text-2xl font-display font-bold",
                        c.probability >= 70 ? "text-neon-red" : c.probability >= 40 ? "text-neon-yellow" : "text-neon-green"
                      )}>
                        {c.probability}%
                      </div>
                      <div className="flex items-center justify-end gap-1 text-[10px] font-mono text-slate-500 uppercase">
                        Trend: {c.trend === 'increasing' ? <TrendingUp className="w-3 h-3 text-neon-green" /> : c.trend === 'decreasing' ? <TrendingDown className="w-3 h-3 text-neon-red" /> : <Minus className="w-3 h-3" />}
                      </div>
                    </div>
                  </div>
                  
                  <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden mb-4">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: `${c.probability}%` }}
                      className={cn("h-full", c.probability >= 70 ? "bg-neon-red" : "bg-neon")}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <div>
                     <p className="text-[8px] font-mono text-slate-600 uppercase tracking-widest mb-2">Evidence Cluster</p>
                     <div className="flex flex-wrap gap-2">
                        {c.evidence.map((e, j) => (
                          <div key={j} className="px-2 py-1 rounded bg-white/5 border border-white/10 text-[9px] font-mono text-slate-400 group-hover:border-white/20 transition-all">
                            {e.year} • {e.marks}m
                          </div>
                        ))}
                     </div>
                   </div>
                   <div className="flex flex-col justify-center">
                     <p className="text-[9px] text-slate-500 italic line-clamp-2">
                       "{c.evidence[0]?.question}"
                     </p>
                   </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Strategy Column */}
        <div className="lg:col-span-4 space-y-6">
          <div className="glass-card p-6 border-neon/20 bg-neon/[0.02]">
            <h4 className="text-[10px] font-mono font-bold text-neon uppercase tracking-[2px] mb-6 flex items-center gap-2">
              <CheckCircle2 className="w-3 h-3" />
              HIGH PRIORITY GAPS
            </h4>
            <div className="space-y-3">
              {data.gaps.map((gap, i) => (
                <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-bg-secondary border border-white/5">
                  <div className="w-1.5 h-1.5 rounded-full bg-neon-red shadow-[0_0_5px_#ff3d6b]" />
                  <span className="text-xs text-slate-300 font-display font-medium">{gap}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="glass-card p-6 border-purple/20 bg-purple/[0.02]">
            <h4 className="text-[10px] font-mono font-bold text-purple uppercase tracking-[2px] mb-6 flex items-center gap-2">
              <Calendar className="w-3 h-3" />
              STUDY PLAN (RECOVERY)
            </h4>
            <div className="space-y-4">
              {data.study_plan.map((day, i) => (
                <div key={i} className="relative pl-4 border-l border-white/10 last:border-b-0 pb-4 last:pb-0">
                  <div className="absolute left-[-4.5px] top-0 w-2 h-2 rounded-full bg-purple" />
                  <p className="text-[9px] font-mono text-slate-500 uppercase tracking-widest mb-1">DAY {day.day} • {day.focus}</p>
                  <ul className="space-y-1">
                    {day.tasks.map((task, j) => (
                      <li key={j} className="text-[11px] text-slate-300 flex items-center gap-2">
                        <ArrowUpRight className="w-3 h-3 text-purple opacity-50" />
                        {task}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
          
          <button className="w-full py-4 rounded-2xl bg-gradient-to-r from-neon to-purple text-white font-display font-bold text-xs uppercase tracking-[2px] shadow-[0_0_30px_rgba(79,158,255,0.2)] hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-3">
             Initialize Practice Session
             <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
