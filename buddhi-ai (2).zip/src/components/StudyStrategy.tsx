import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function StudyStrategy() {
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetch('/api/plan').then(res => res.json()).then(setData);
  }, []);

  if (!data) return null;

  return (
    <div className="space-y-8 h-full flex flex-col">
      <div>
        <h1 className="text-4xl font-display font-medium text-white mb-2">Study Strategy</h1>
        <p className="text-[10px] font-mono text-slate-500 uppercase tracking-[4px]">PERSONALIZED TRAJECTORY • DAY BY DAY</p>
      </div>

      <div className="max-w-4xl mx-auto w-full space-y-6 overflow-y-auto custom-scrollbar pr-4 flex-1 pb-10">
        {data.schedule.map((day: any, i: number) => (
          <motion.div 
            key={day.day}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="glass-card p-8 group hover:bg-white/[0.03] transition-all relative overflow-hidden"
          >
            {/* Subtle progress indicator on the left */}
            <div className={cn(
              "absolute left-0 top-0 bottom-0 w-1 transition-all",
              day.day === 1 ? "bg-neon shadow-[0_0_10px_#4f9eff]" : 
              day.day === 2 ? "bg-purple shadow-[0_0_10px_#a855f7]" : "bg-white/10"
            )} />

            <div className="flex flex-col gap-6">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-[2px] mb-2 block group-hover:text-neon transition-colors">DAY {day.day}</span>
                  <h3 className="text-2xl font-display font-medium text-white group-hover:text-white transition-colors uppercase tracking-tight">{day.focus}</h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest block mb-1">
                    {day.day === 1 ? '100% COMPLETE' : day.day === 2 ? '10% COMPLETE' : 'NOT STARTED'}
                  </span>
                  <div className="w-32 h-1.5 bg-white/5 rounded-full overflow-hidden">
                    <motion.div 
                      initial={{ width: 0 }}
                      animate={{ width: day.day === 1 ? '100%' : day.day === 2 ? '10%' : '0%' }}
                      className="h-full bg-gradient-to-r from-purple to-cyan"
                    />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4">
                {day.tasks.map((task: string, j: number) => (
                  <div key={j} className="flex items-center gap-4 group/item cursor-pointer">
                    <div className={cn(
                      "w-5 h-5 rounded border flex items-center justify-center transition-all",
                      day.day === 1 
                        ? "bg-neon/10 border-neon/30 text-neon" 
                        : "bg-white/5 border-white/10 text-transparent group-hover/item:border-neon group-hover/item:bg-neon/10"
                    )}>
                      {day.day === 1 && <Check className="w-3 h-3" />}
                    </div>
                    <span className={cn(
                      "text-sm tracking-wide transition-colors",
                      day.day === 1 ? "text-slate-500 line-through" : "text-slate-300 group-hover/item:text-white"
                    )}>
                      {task}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function Check({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="4" 
      strokeLinecap="round" 
      strokeLinejoin="round"
    >
      <polyline points="20 6 9 17 4 12" />
    </svg>
  );
}
