import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LayoutDashboard, 
  BrainCircuit, 
  BookOpen, 
  MessageSquare, 
  HeartPulse, 
  User, 
  Zap, 
  AlertCircle,
  Bell
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Pages
import Dashboard from './components/Dashboard';
import Practice from './components/Practice';
import StudyStrategy from './components/StudyStrategy';
import AIChat from './components/AIChat';
import Wellness from './components/Wellness';
import Profile from './components/Profile';

// Types
import { UIState } from './types';

import { cn } from './lib/utils';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [uiState, setUiState] = useState<UIState>('NORMAL');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Background Mesh based on UI State
  const meshColors = {
    NORMAL: 'from-violet-900/20 to-bg',
    HIGH_YIELD: 'from-amber-900/30 to-bg animate-pulse',
    FOCUS: 'from-blue-900/40 to-bg',
    FATIGUE_DETECTED: 'from-red-900/20 to-bg'
  };

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'practice', label: 'Practice', icon: BookOpen },
    { id: 'strategy', label: 'Strategy', icon: BrainCircuit },
    { id: 'chat', label: 'AI Chat', icon: MessageSquare },
    { id: 'wellness', label: 'Wellness', icon: HeartPulse },
    { id: 'profile', label: 'Profile', icon: User },
  ];

  return (
    <div className={cn(
      "min-h-screen bg-bg transition-colors duration-1000 overflow-x-hidden",
      uiState === 'FATIGUE_DETECTED' && "sepia-[0.3]"
    )}>
      {/* Dynamic Background Mesh */}
      <div className={cn(
        "fixed inset-0 bg-gradient-to-tr transition-all duration-1000 z-0 opacity-50",
        meshColors[uiState]
      )} />
      
      {/* Floating Particles Placeholder */}
      <div className="fixed inset-0 pointer-events-none opacity-20 z-0">
        <div className="absolute top-1/4 left-1/4 w-1 h-1 bg-neon rounded-full animate-ping" />
        <div className="absolute top-3/4 left-2/3 w-1 h-1 bg-purple rounded-full animate-ping [animation-delay:1s]" />
      </div>

      <div className="flex relative z-10 h-screen">
        {/* Futuristic Sidebar */}
        <motion.aside 
          initial={false}
          animate={{ width: isSidebarOpen ? 260 : 80 }}
          className="border-r border-white/5 bg-bg-secondary/80 backdrop-blur-2xl flex flex-col pt-6"
        >
          <div className="px-6 mb-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-neon rounded-xl flex items-center justify-center shadow-[0_0_20px_#4f9eff60]">
                <Zap className="text-white w-6 h-6 fill-white" />
              </div>
              {isSidebarOpen && (
                <div className="flex flex-col">
                  <motion.span 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="font-display font-bold text-lg tracking-tight text-white leading-none"
                  >
                    Buddhi AI
                  </motion.span>
                  <span className="text-[10px] font-mono text-slate-500 mt-1 uppercase tracking-widest">v2 • LIVE</span>
                </div>
              )}
            </div>
          </div>

          <nav className="flex-1 px-4 space-y-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all group border border-transparent",
                  activeTab === tab.id 
                    ? "bg-white/5 text-neon border-white/5 shadow-[inset_0_0_10px_rgba(255,255,255,0.02)]" 
                    : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                )}
              >
                <tab.icon className={cn(
                  "w-5 h-5 transition-transform",
                  activeTab === tab.id && "scale-110 text-neon"
                )} />
                {isSidebarOpen && (
                  <motion.span 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="font-display font-medium text-sm tracking-wide"
                  >
                    {tab.label}
                  </motion.span>
                )}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-white/5 bg-bg/40">
            {isSidebarOpen && (
              <div className="mb-4">
                <p className="text-[8px] font-mono text-slate-600 uppercase tracking-[2px] mb-2 px-2">App Mode</p>
                <div className="relative">
                  <select 
                    value={uiState}
                    onChange={(e) => setUiState(e.target.value as UIState)}
                    className="w-full bg-bg/80 border border-white/10 text-white rounded-lg px-3 py-2 text-xs font-display appearance-none cursor-pointer focus:outline-none focus:border-neon"
                  >
                    <option value="NORMAL">Normal</option>
                    <option value="HIGH_YIELD">High-Yield</option>
                    <option value="FOCUS">Focus Mode</option>
                    <option value="FATIGUE_DETECTED">Rest Advice</option>
                  </select>
                  <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none text-slate-500">
                    <AlertCircle className="w-3 h-3" />
                  </div>
                </div>
              </div>
            )}
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="w-full py-2 flex justify-center text-slate-500 hover:text-slate-300"
            >
              {isSidebarOpen ? "«" : "»"}
            </button>
          </div>
        </motion.aside>

        {/* Main Content Area */}
        <main className="flex-1 flex flex-col h-full overflow-hidden">
          {/* Header */}
          <header className="h-20 border-b border-white/5 flex items-center justify-between px-8 bg-bg/50 backdrop-blur-md">
            <div className="flex items-center gap-4">
               {uiState === 'FATIGUE_DETECTED' && (
                 <motion.div 
                   initial={{ opacity: 0, y: -20 }}
                   animate={{ opacity: 1, y: 0 }}
                   className="flex items-center gap-2 bg-red-500/20 text-neon-red px-4 py-2 rounded-full border border-neon-red/30 text-xs font-bold uppercase tracking-widest"
                 >
                   <AlertCircle className="w-4 h-4" />
                   Fatigue Detected: Take a Break
                 </motion.div>
               )}
            </div>

            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 px-3 py-1.5 glass rounded-full">
                <div className="w-2 h-2 rounded-full bg-neon-green animate-pulse" />
                <span className="text-[10px] font-mono text-slate-400">SYNCED</span>
              </div>
              <button className="text-slate-400 hover:text-neon transition-colors relative">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-2 h-2 bg-neon-red rounded-full flex items-center justify-center text-[8px] text-white">2</span>
              </button>
              <div className="flex items-center gap-3 pl-4 border-l border-white/10">
                <div className="text-right">
                  <p className="text-xs font-bold text-white">XYZ</p>
                  <p className="text-[10px] text-neon font-mono">Rank: Elite Strategist</p>
                </div>
                <div className="w-10 h-10 rounded-full border-2 border-neon/50 p-0.5">
                  <img src="https://api.dicebear.com/7.x/avataaars/svg?seed=Lucky" className="rounded-full bg-bg-secondary" alt="avatar" />
                </div>
              </div>
            </div>
          </header>

          {/* Page Content */}
          <div className="flex-1 overflow-y-auto p-8 relative">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ type: "spring", damping: 25, stiffness: 200 }}
                className="h-full"
              >
                {activeTab === 'dashboard' && <Dashboard uiState={uiState} />}
                {activeTab === 'practice' && <Practice onStateChange={setUiState} />}
                {activeTab === 'strategy' && <StudyStrategy />}
                {activeTab === 'chat' && <AIChat />}
                {activeTab === 'wellness' && <Wellness />}
                {activeTab === 'profile' && <Profile />}
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
}
