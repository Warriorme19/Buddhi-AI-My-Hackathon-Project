import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { fileURLToPath } from 'url';

// Intelligence Engine Services
import { 
  analyzeDocument, 
  getProbability, 
  getTrends, 
  getGapAnalysis, 
  getStudyPlan, 
  getChatResponse,
  trackPractice,
  getEvidence
} from './server/services/intelligence.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API ROUTES ---

  // 1. Upload & Processing
  app.post('/api/upload', (req, res) => {
    // Logic for PDF/Text extraction
    const result = analyzeDocument(req.body);
    res.json(result);
  });

  // 2-4. Probability & Concept Mapping
  app.get('/api/probability', (req, res) => {
    res.json(getProbability());
  });

  // 5. Trend Detection
  app.get('/api/trend', (req, res) => {
    res.json(getTrends());
  });

  // 6. Gap Analysis
  app.get('/api/gap', (req, res) => {
    res.json(getGapAnalysis());
  });

  // 7-9. Practice Tracking & Stress Detection
  app.post('/api/practice', (req, res) => {
    const result = trackPractice(req.body);
    res.json(result);
  });

  // 10. Study Plan Generator
  app.get('/api/plan', (req, res) => {
    res.json(getStudyPlan());
  });

  // 11. Evidence Layer
  app.get('/api/analyze', (req, res) => {
    res.json(getEvidence(req.query.topic as string));
  });

  // 12. Chat API
  app.post('/api/chat', (req, res) => {
    res.json(getChatResponse(req.body.message));
  });

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', engine: 'Intelligence Engine V2 active' });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Buddhi AI Server running on http://localhost:${PORT}`);
  });
}

startServer();
